create table user (
id int  not null auto_increment,
name varchar(50) not null,
edad int not null,
email varchar(100)not null,
PRIMARY KEY(id)
);

INSERT INTO user (name, edad,email) VALUES ('oscar',25,'oscar@gmail,com');
INSERT INTO user (name, edad,email) VALUES ('layla',15,'layla@gmail,com');
INSERT INTO user (name, edad,email) VALUES ('nicolas',36,'nicolas@gmail,com');
INSERT INTO user (name, edad,email) VALUES ('chanchito',7,'chanchito@gmail,com');

select * from user;
select * from user limit 1;
select * from user where edad > 15;
select * from user where edad >= 15;
select * from user where edad >20 and email ='nicolas@gmail,com';
select * from user where edad >20 or email ='layla@gmail,com';
select * from user where email !='layla@gmail,com';
select * from user where edad between 15 and 30;
select * from user where email like '%gmail%';

