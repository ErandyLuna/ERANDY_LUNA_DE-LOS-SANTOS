create table products (
  id int not null auto_increment,
  name varchar(50) not null,
  created_by int not null,
  marca varchar(50) not null,
  primary key(id),
  foreign key (created_by) references user (id)
);

rename table products to product;
-- cambiar nombre de la tabla 

insert into product (name,created_by,marca)
values 
      ('ipad',1,'apple'),
      ('iphone',1,'apple'),
      ('watch',2,'apple'),
      ('macbook',1,'apple'),
      ('imac',3,'apple'),
      ('ipad mini',2,'apple');

select * from product;
-- left
select u.id, u.email, p.name from user u left join product p on u.id = p.created_by;
-- right
select u.id, u.email, p.name from user u right join product p on u.id = p.created_by;
-- inner
select u.id, u.email, p.name from user u inner join t p on u.id = p.created_by;
-- cross
select u.id, u.name, p.id, p.name from user u cross join product p;
-- group by 
select count(id), marca from product group by marca;
select count(p.id), u.name from product p left join user u
on u.id = p.created_by group by p.created_by;
-- having count
select count(p.id), u.name from product p left join user u
on u.id = p.created_by group by p.created_by
having count(p.id)>=2;
-- elimida 
drop table product;
drop table animales;
drop table user;
