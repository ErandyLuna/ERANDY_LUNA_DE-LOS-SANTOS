create database holamundo;
show databases;
use holamundo;
create table animales (
id int,
tipo varchar(255),
estado varchar(255),
PRIMARY KEY(id)
);

-- INSERT INTO animales (tipo,estado) VALUES ('canchito','feliz');
-- esta linea no se ejeutara  

ALTER TABLE animales MODIFY COLUMN id int auto_increment;

show create table animales;

CREATE TABLE `animales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO animales (tipo,estado) VALUES ('canchito','feliz');
INSERT INTO animales (tipo,estado) VALUES ('dragon','feliz');
INSERT INTO animales (tipo,estado) VALUES ('felipe','triste');

select * from animales;
select * from animales where id =1;
select * from animales where estado ='feliz';
select * from animales where estado ='feliz' and tipo = 'canchito';
select * from animales where estado ='feliz' and tipo = 'felipe';

update animales set estado ='feliz' where id =3;

select * from animales;

delete from animales where estado = 'feliz';

-- Error Code: 1175. You are using safe update mode and you tried to update a table without a WHERE that uses a KEY column.  
-- To disable safe mode, toggle the option in Preferences -> SQL Editor and reconnect.
delete from animales where id = 4;

